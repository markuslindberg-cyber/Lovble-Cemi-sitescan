import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, MapPin, Camera } from 'lucide-react';
import ReportFrontPage from './ReportFrontPage';
import ReportSummaryPage from './ReportSummaryPage';
import MapWithMarkers from './MapWithMarkers';

const severityColors = {
  low: 'bg-blue-100 text-blue-800 border-blue-200',
  medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  high: 'bg-orange-100 text-orange-800 border-orange-200',
  critical: 'bg-red-100 text-red-800 border-red-200'
};

const markerColors = {
  low: 'bg-blue-500 border-blue-600',
  medium: 'bg-yellow-500 border-yellow-600',
  high: 'bg-orange-500 border-orange-600',
  critical: 'bg-red-500 border-red-600'
};

export default function ReportContent({ inspection, site, customer, points }) {
  const getSummary = () => {
    const summary = {
      low: points.filter(p => p.severity === 'low').length,
      medium: points.filter(p => p.severity === 'medium').length,
      high: points.filter(p => p.severity === 'high').length,
      critical: points.filter(p => p.severity === 'critical').length
    };
    return summary;
  };

  const summary = getSummary();

return (
   <>
     <style>{`
       @media print {
         @page { 
           size: A4 portrait; 
           margin: 20mm;
         }
         html, body { 
           margin: 0 !important; 
           padding: 0 !important;
           background: white !important;
         }
         * { 
           -webkit-print-color-adjust: exact !important; 
           print-color-adjust: exact !important;
         }
         h1 { font-size: 24pt !important; }
         h2 { font-size: 18pt !important; }
         p, div { font-size: 11pt !important; }
         .inspection-point-item {
           page-break-inside: avoid !important;
           break-inside: avoid !important;
           page-break-before: auto !important;
         }
         .inspection-point-item:nth-of-type(n+2) {
           page-break-before: always !important;
         }
         .page-header {
           border-bottom: 1px solid #e5e7eb !important;
           margin-bottom: 0.125rem !important;
           padding-bottom: 0.0625rem !important;
           text-align: right !important;
           font-size: 9pt !important;
           color: #666 !important;
         }
       }
       .page-header {
         text-align: right;
         font-size: 0.75rem;
         color: #666;
         margin-bottom: 0.125rem;
         padding-bottom: 0.0625rem;
         border-bottom: 1px solid #e5e7eb;
       }

     `}</style>
      {/* Front Page */}
      <div style={{ pageBreakAfter: 'always' }}>
         <div className="page-header">Sida 1</div>
         <ReportFrontPage inspection={inspection} site={site} customer={customer} />
      </div>

      {/* Summary Page */}
      <div style={{ pageBreakAfter: 'always' }}>
         <div className="page-header">Sida 2</div>
         <ReportSummaryPage inspection={inspection} site={site} customer={customer} points={points} />
      </div>

      {/* Page 3: Detailed Report Overview */}
      <div className="bg-white p-4 md:p-8 print:p-0" style={{ pageBreakAfter: 'always' }}>
          <div className="page-header">Sida 3</div>
          <div>
            {/* Header Section */}
            <div className="mb-6 pb-4 border-b-2 border-gray-300">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-sm font-bold px-3 py-1 bg-gray-800 text-white rounded">
                  {inspection.inspection_number}
                </span>
                <span className="text-sm text-gray-500">Besiktnings-ID</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2 leading-tight">
                {inspection.report_title || 'Detaljerad besiktningsrapport'}
              </h1>
              <h2 className="text-lg md:text-xl text-gray-700 mb-4">{site.name}</h2>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <p className="text-xs uppercase tracking-wider text-gray-500 mb-1">Besiktningsdatum</p>
                  <p className="text-sm font-semibold text-gray-900">
                    {new Date(inspection.inspection_date).toLocaleDateString('sv-SE', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </p>
                  </div>
                  <div>
                  <p className="text-xs uppercase tracking-wider text-gray-500 mb-1">Besiktningsman</p>
                  <p className="text-sm font-semibold text-gray-900">{inspection.inspector_name}</p>
                </div>
                {customer && (
                  <div>
                    <p className="text-xs uppercase tracking-wider text-gray-500 mb-1">Kund</p>
                    <p className="text-sm font-semibold text-gray-900">{customer.name}</p>
                    {customer.project_number && (
                      <p className="text-xs text-gray-600">Projekt: {customer.project_number}</p>
                    )}
                  </div>
                  )}
                  {site.location && (
                  <div>
                    <p className="text-xs uppercase tracking-wider text-gray-500 mb-1">Plats</p>
                    <p className="text-sm text-gray-900">{site.location}</p>
                  </div>
                  )}
              </div>
            </div>

            {/* Map Section */}
            <div className="mb-8">
              <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Platsöversikt</h2>
              <div className="relative w-full">
                {inspection.map_screenshot_url ? (
                  <img
                    src={inspection.map_screenshot_url}
                    alt="Site map with inspection points"
                    className="w-full h-auto object-contain border border-gray-300 rounded-lg"
                    crossOrigin="anonymous"
                    loading="eager"
                  />
                ) : site.map_image_url ? (
                    <MapWithMarkers imageUrl={site.map_image_url} points={points} />
                  ) : site.map_type === 'google_maps' && site.google_maps_center ? (
                    <div className="p-6 bg-gray-50 border border-gray-300 rounded-lg">
                      <div className="space-y-3">
                        <div>
                          <p className="text-xs font-semibold text-gray-700 mb-1">Koordinater</p>
                              <p className="text-sm text-gray-900">Lat: {site.google_maps_center.lat.toFixed(6)}, Lng: {site.google_maps_center.lng.toFixed(6)}</p>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-gray-700 mb-1">Visa i kartor</p>
                              <a href={`https://maps.apple.com/?ll=${site.google_maps_center.lat},${site.google_maps_center.lng}&z=${site.google_maps_zoom || 18}`} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 hover:underline break-all">
                                Apple Maps-länk
                          </a>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 text-center text-gray-500">
                      <p>Ingen karta konfigurerad för denna plats</p>
                    </div>
                  )}
              </div>

              <div className="mt-8" style={{ pageBreakBefore: 'always' }}>
                <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-4">Detaljerade fynd ({points.length} punkter)</h2>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <p className="text-sm font-semibold text-gray-700 mb-3">Punktöversikt:</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {points.map((point, index) => (
                      <div key={point.id} className="text-sm text-gray-600">
                        <span className="font-medium">Punkt {index + 1}:</span> Sida {index + 4}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>

            {/* Inspection Points - Each on its own page */}
            {points.map((point, index) => (
            <div key={point.id} className="bg-white p-4 md:p-8 print:p-0" style={{ pageBreakAfter: index === points.length - 1 ? 'auto' : 'always' }}>
            <div className="page-header">Sida {index + 4}</div>
            <div className="flex gap-4">
            <div className="flex-shrink-0 w-10 h-10 bg-gray-800 text-white rounded-full flex items-center justify-center font-bold text-lg">
              {index + 1}
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <Badge className={`${severityColors[point.severity || 'medium']} border font-semibold uppercase text-xs px-3 py-1`}>
                  {({ low: 'Låg', medium: 'Medel', high: 'Hög', critical: 'Kritisk' })[point.severity || 'medium']}
                </Badge>
                <span className="text-sm font-semibold text-gray-800 capitalize">
                  {({
                    improvement_suggestions: 'Förbättringsförslag',
                    issue_damage: 'Skada',
                    plant_health: 'Växthälsa',
                    maintenance: 'Underhåll',
                    safety_concern: 'Säkerhetsrisk',
                    deviation: 'Avvikelse'
                  })[point.issue_type] || point.issue_type?.replace(/_/g, ' ')}
                </span>
              </div>

              {point.notes && (
                <p className="text-sm text-gray-700 leading-relaxed mb-4">{point.notes}</p>
              )}

              {point.photo_details && point.photo_details.length > 0 && (
                <div className="mt-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-gray-600 mb-3">
                    <Camera className="w-4 h-4" />
                    Dokumentation ({point.photo_details.length} {point.photo_details.length === 1 ? 'foto' : 'foton'})
                  </div>
                  <div className="grid grid-cols-2 gap-3 print:gap-2">
                    {point.photo_details.map((photo, photoIndex) => (
                      <div key={photoIndex}>
                        <img
                         src={photo.url}
                         alt={`Point ${index + 1} photo ${photoIndex + 1}`}
                         className="w-full h-auto object-contain rounded-lg border border-gray-300"
                         crossOrigin="anonymous"
                         loading="eager"
                        />
                        {(photo.comment || photo.show_address) && (
                          <div className="mt-1 space-y-1">
                            {photo.show_address && (
                              <p className="text-xs text-blue-700 bg-blue-50 p-1.5 rounded print:text-[9pt]">
                                📍 Plats: {photo.address || 'Okänd'}
                              </p>
                            )}
                            {photo.comment && (
                              <p className="text-xs text-gray-600 italic bg-gray-50 p-1.5 rounded print:text-[9pt]">
                                {photo.comment}
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {point.latitude && point.longitude && (
                <div className="mt-3 text-xs text-gray-500 bg-gray-50 px-3 py-2 rounded inline-block">
                  <MapPin className="w-3 h-3 inline mr-1" />
                  GPS: {point.latitude.toFixed(6)}, {point.longitude.toFixed(6)}
                </div>
              )}
              </div>
              </div>
              </div>
              ))}
    </>
  );
}